<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="<?= csrf_token() ?>" content="<?= csrf_hash() ?>" class="csrf">
    <title><?= $this->renderSection("title") ?> </title>

    <!-- Sweet alert -->
    <link rel="stylesheet" href="css/sweetalert2.min.css">
</head>
<body>
   
    <a href="<?= site_url("/home") ?>">Home</a>

    <?php if(current_user()): ?> 

       <p>Hello <?= esc(current_user()->name) ?></p>

       <a href="<?= site_url("/tasks") ?>">Tasks</a>

     <!-- <form action="<?php //echo route_to('user.logout'); ?>" method="post" id="logout-form" autocomplete="off">
       <?php //echo csrf_field(); ?>
       <button type="submit" class="btn btn-primary btn-block"> Log Out </button>
     </form> -->
        
        <a href="<?= site_url("/logout") ?>">Log out</a>

    <?php else: ?> 

       <a href="<?= site_url("/signup") ?>">Sign up</a>

       <a href="<?= site_url("/login") ?>">Log in</a>

    <?php endif; ?>

    <?php if(session()->has('warning')): ?>
        <div class="warning">
            <?= session('warning') ?>
        </div>
    <?php endif; ?>

    <?php if(session()->has('info')): ?>
        <div class="info">
            <?= session('info') ?>
        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="error">
            <?= session('error') ?>
        </div>
    <?php endif; ?>

    <?= $this->renderSection("content") ?>

</body>
</html>

<!-- jQuery -->
<script src="AdminLTE/plugins/jquery/jquery.min.js"></script>

<!--Sweet alert-->
<script src="js/sweetalert.min.js"></script>
<!-------->


<!----------Logout--------------->

<!-- <script>
      var csrfName = $('meta.csrf').attr('name'); //CSRF TOKEN NAME
      var csrfHash = $('meta.csrf').attr('content'); //CSRF HASH
      
      $('#logout-form').submit(function(e){
            e.preventDefault();
            alert("here");
            var form = this;
            $.ajax({
              url:$(form).attr('action'),
              method:$(form).attr('method'),
              data:new FormData(form),
              processData:false,
              dataType:'json',
              contentType:false,
              beforeSend:function(){ 
              },
              success:function(data){
                    if($.isEmptyObject(data.error)){
                        if(data.code == 1){
                            $(form)[0].reset();
                            swal("You are successfully logged out!", "", "success");  
                            // location.reload();
                            window.location = "<?php  echo site_url('/'); ?>";
                        } 
                    }else{
                        swal(data.error, "", "error"); 
                    }
                    
              }
            });
      });

</script> -->

<!------------Logout------------------->

<?= $this->renderSection('scripts'); ?>