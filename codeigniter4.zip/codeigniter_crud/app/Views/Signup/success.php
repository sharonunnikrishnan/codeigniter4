<?= $this->extend("Layouts/default") ?>

<?= $this->section("title") ?> Signup <?= $this->endSection() ?>

<?= $this->section("content"); ?>

    <h1>Signup</h1>
    <p>Signup successfull</p>

<?= $this->endSection(); ?>