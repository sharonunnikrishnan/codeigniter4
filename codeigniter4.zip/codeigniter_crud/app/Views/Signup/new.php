<?= $this->extend("Layouts/signup") ?>

<?= $this->section("title") ?> Signup <?= $this->endSection() ?>

<?= $this->section("content"); ?>

    <?php if(session()->has('errors')): ?>
        <ul>
            <?php foreach(session('errors') as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif ?>

    

    <?php //form_open("/signup/create") ?>
    <form action="<?= route_to('add.user'); ?>" method="post" id="signup-form" autocomplete="off">
        <?= csrf_field(); ?>

        <span class="text-danger error-text name_error"></span>
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Full name" name="name" id="name" value="<?= old('name') ?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        
        <span class="text-danger error-text email_error"></span>
        <div class="input-group mb-3">
          <input type="email" class="form-control" placeholder="Email" name="email" id="email" value="<?= old('email') ?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>

        <span class="text-danger error-text password_error"></span>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password"  name="password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>

        <span class="text-danger error-text password_confirmation_error"></span>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Retype password" name="password_confirmation">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="agreeTerms" name="terms" value="agree">
              <label for="agreeTerms">
               I agree to the <a href="#">terms</a>
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block" id="submit-btn">Register</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <div class="social-auth-links text-center">
        <p>- OR -</p>
        <a href="#" class="btn btn-block btn-primary">
          <i class="fab fa-facebook mr-2"></i>
          Sign up using Facebook
        </a>
        <a href="#" class="btn btn-block btn-danger">
          <i class="fab fa-google-plus mr-2"></i>
          Sign up using Google+
        </a>
      </div>

      <div id="abc"></div>
      <a href="login.html" class="text-center">I already have a membership</a>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>

  <script>
      var csrfName = $('meta.csrf').attr('name'); //CSRF TOKEN NAME
      var csrfHash = $('meta.csrf').attr('content'); //CSRF HASH
      
      
      
      $('#signup-form').submit(function(e){
            e.preventDefault();
            
            var form = this;
            $.ajax({
              url:$(form).attr('action'),
              method:$(form).attr('method'),
              data:new FormData(form),
              processData:false,
              dataType:'json',
              contentType:false,
              beforeSend:function(){
                $(form).find('span.error-text').text('');
              },
              success:function(data){
                    if($.isEmptyObject(data.error)){
                        if(data.code == 1){
                            $(form)[0].reset();
                            swal("Successfully signed up!", "", "success");  
                            window.location = "<?php  echo site_url('login'); ?>";
                        }else{
                            alert(data.msg); 
                        }
                    }else{
                        swal("Something went wrong!", "", "error"); 
                        $.each(data.error, function(prefix, val){
                            $(form).find('span.'+prefix+'_error').text(val);
                        }); 
                    }
                    
              }
            });
      });

  </script>

<?= $this->endSection(); ?>