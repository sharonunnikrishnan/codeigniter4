<?= $this->extend("Layouts/default") ?>

<?= $this->section("title") ?> Task <?= $this->endSection() ?>

<?= $this->section("content"); ?>

    <h1>Task</h1>

    <a href='<?= site_url("/tasks") ?>'>Back</a>
    <table border="1">
        <tr><th>ID</th> <th>Description</th> <th>Created At</th> <th>Updated At</th></tr>
        <tr>
            <td><?= $task->id ?></td>
            <td><?= $task->description ?> </td>
            <td><?= $task->created_at ?> </td>
            <td><?= $task->updated_at ?> </td>
        </tr>
    </table>

    <a href='<?= site_url("/tasks/edit/". $task->id) ?>'>Edit</a>
    <a href='<?= site_url("/tasks/delete/". $task->id) ?>'>Delete</a>

<?= $this->endSection(); ?>