<?= $this->extend("Layouts/default") ?>

<?= $this->section("title") ?> Tasks <?= $this->endSection() ?>

<?= $this->section("content"); ?>

    <h1>Tasks</h1>

    <a href="/tasks/new">Create a Task >></a>

    <?php if($tasks): ?>

        <ul>
            <?php foreach($tasks as $task): ?>

                <li><a href="<?= site_url('tasks/show/'. $task->id) ?>"><?= $task->id ?> :  <?= esc($task->description) ?></a></li> 

            <?php endforeach; ?>
        </ul>
    
    <?= $pager->links(); ?>

    <?php else: ?>

        <p>No tasks found.</p>

    <?php endif; ?>

<?= $this->endSection(); ?>