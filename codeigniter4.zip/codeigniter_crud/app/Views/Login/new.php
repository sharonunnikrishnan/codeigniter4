
<?= $this->extend("Layouts/login") ?>

<?= $this->section("title") ?> Login <?= $this->endSection() ?>

<?= $this->section("content"); ?>

      <?php //echo form_open("/login/create") ?>
      <form action="<?= route_to('user.login'); ?>" method="post" id="login-form" autocomplete="off">
        <?= csrf_field(); ?>
        <span class="text-danger error-text email_error"></span>
        <div class="input-group mb-3">
          <input type="email" name="email" id="email" value="<?= old('email') ?>" class="form-control" placeholder="Email">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>

        <span class="text-danger error-text password_error"></span>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password" name="password" id="password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Remember Me
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <div class="social-auth-links text-center mb-3">
        <p>- OR -</p>
        <a href="#" class="btn btn-block btn-primary">
          <i class="fab fa-facebook mr-2"></i> Sign in using Facebook
        </a>
        <a href="#" class="btn btn-block btn-danger">
          <i class="fab fa-google-plus mr-2"></i> Sign in using Google+
        </a>
      </div>
      <!-- /.social-auth-links -->

      <p class="mb-1">
        <a href="forgot-password.html">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="register.html" class="text-center">Register a new membership</a>
      </p>
   

<?= $this->endSection(); ?>
      
<?= $this->section('scripts'); ?>

  <script>
      var csrfName = $('meta.csrf').attr('name'); //CSRF TOKEN NAME
      var csrfHash = $('meta.csrf').attr('content'); //CSRF HASH
      
      
      
      $('#login-form').submit(function(e){
            e.preventDefault();
            
            var form = this;
            $.ajax({
              url:$(form).attr('action'),
              method:$(form).attr('method'),
              data:new FormData(form),
              processData:false,
              dataType:'json',
              contentType:false,
              beforeSend:function(){
                $(form).find('span.error-text').text('');
              },
              success:function(data){
                    if($.isEmptyObject(data.error)){
                        if(data.code == 1){
                            $(form)[0].reset();
                            swal("You are successfully logged in!", " ", "success");  
                            window.location = data.url;
                        } 
                        else
                        {
                          swal(data.msg, " ", "warning");; 
                        }
                    }else{
                        swal("Something went wrong!", "", "error");  
                        $.each(data.error, function(prefix, val){
                            $(form).find('span.'+prefix+'_error').text(val);
                        }); 
                    }
                    
              }
            });
      });

  </script>

<?= $this->endSection(); ?>