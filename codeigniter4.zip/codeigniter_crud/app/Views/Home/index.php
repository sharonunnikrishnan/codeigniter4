<?= $this->extend("Layouts/default") ?>

<?= $this->section("title") ?> Home <?= $this->endSection() ?>

<?= $this->section("content"); ?>

    <h1>Welcome</h1>

    

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>

  

<?= $this->endSection(); ?>