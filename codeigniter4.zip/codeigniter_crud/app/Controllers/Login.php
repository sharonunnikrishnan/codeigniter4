<?php

namespace App\Controllers;

class Login extends BaseController
{
    public function new()
    {
        return view('Login/new');
    }

    public function create()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // $auth = \Config\Services::auth();
        $auth = service('auth');

        $validation = \Config\Services::validation();
        $this->validate([
             'email'=>[
                 'rules'=>'required',
                 'errors'=>[
                     'required'=>'Email is required'
                 ]
             ], 
             'password'=>[
                  'rules'=>'required',
                  'errors'=>[
                      'required'=>'Password is required'
                  ]
            ]
        ]);

        if($validation->run() == FALSE){
            $errors = $validation->getErrors();
            echo json_encode(['code'=>0, 'error'=>$errors]);
            exit;
        }


        if($auth->login($email, $password))
        {
            $redirect_url = session('redirect_url()') ?? '/';

            unset($_SESSION['redirect_url']);

            echo json_encode(['code'=>1, 'error'=> '', 'url' => $redirect_url]);
            exit;
        }
        else
        {
            echo json_encode(['code'=>0, 'error'=> 'Invalid Login']);
            exit;
        }
    }

    public function delete()
    {
        $auth = service('auth');

        $auth->logout();

        return redirect()->to('/login')
                         ->withCookies();
    }

}