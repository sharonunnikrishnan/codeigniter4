<?php

namespace App\Controllers;

class Signup extends BaseController
{
    public function new()
    {
        return view('Signup/new');
    }

    public function create()
    {
        $user = new \App\Entities\User($this->request->getPost());

        $model = new \App\Models\UserModel;

        $validation = \Config\Services::validation();
        $this->validate([
             'email'=>[
                 'rules'=>'required|is_unique[user.email]',
                 'errors'=>[
                     'required'=>'Email is required',
                     'is_unique'=>'This email is already exists',
                 ]
             ],
             'name'=>[
                  'rules'=>'required',
                  'errors'=>[
                      'required'=>'Name is required'
                  ]
             ],
             'password'=>[
                  'rules'=>'required|min_length[6]',
                  'errors'=>[
                      'required'=>'Password is required'
                  ]
            ],
            'password_confirmation' =>[
                'rules' =>'required|matches[password]',
                'errors'=>[
                    'required' => 'Please confirm the password',
                    'matches' => 'Please enter the same password again'
                ]
            ] 

        ]);
        
        if($validation->run() == FALSE){
            $errors = $validation->getErrors();
            echo json_encode(['code'=>0, 'error'=>$errors]);
            exit;
        }
        // echo json_encode(['code'=>$user->email, 'error'=>'error']);
        

        if($model->insert($user))
        {
            echo json_encode(['code'=>1, 'msg'=>"Success"]);
            exit;
        }
        else 
        {
            echo json_encode(['code'=>0, 'error'=> $model->errors()]);
            exit;
        }
        
        
    }

    public function success()
    {
        return view('Signup/success');
    }
}

?>