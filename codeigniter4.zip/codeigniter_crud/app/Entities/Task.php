<?php

namespace App\Entities;

class Task extends \CodeIgniter\Entity
{
    
} 

?>